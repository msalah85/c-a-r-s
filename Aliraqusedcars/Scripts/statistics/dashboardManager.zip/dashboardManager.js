﻿var dashboardManager = function () {

    var
        init = function () {
            initProperties();
        },
        initProperties = function () {

            var
                bindChartData = function (data) {
                    var dAll = commonManger.comp2json(data.d),
                        list = dAll.list; //, list1 = dAll.list1, list2 = dAll.list2;

                    ///=======================================================
                    //var d1 = [], d2 = [], d3 = [];
                    //$.each(list, function (i, v) {
                    //    if (v.ShipperID == '4') { // Atlantic
                    //        // get date in number format
                    //        d1.push([moment(v.InvMonth + '/' + v.InvYear, 'MM/YYYY').valueOf(), v['LoadAvg']]);
                    //    }
                    //});
                    //$.each(list, function (i, v) {
                    //    if (v.ShipperID == '2') // W8
                    //        d2.push([moment(v.InvMonth + '/' + v.InvYear, 'MM/YYYY').valueOf(), v['ShipAvg']]);
                    //});
                    //$.each(list, function (i, v) {
                    //    if (v.ShipperID == '6') // Ariana
                    //        d3.push([moment(v.InvMonth + '/' + v.InvYear, 'MM/YYYY').valueOf(), v['LoadAvg']]);
                    //});
                    //=======================================================
                    //var _data = [
                    //    { label: "W8 Shipping", data: d1 },//, bars: { show: true, barWidth: 0.5 }
                    //    { label: "Ariana", data: d2 },
                    //    { label: "GulfAuto", data: d3 }
                    //];
                    //=======================================================

                    var groupedData = _.groupBy(list, 'ShipCompanyNameEn'),
                        _dta = [];

                    
                    $.each(groupedData, function (key, item) {
                        _dta.push({
                            label: key, data: $.map(item, function (v, i) {
                                var subData = [];
                                subData.push([moment(v.InvMonth + '/' + v.InvYear, 'MM/YYYY').valueOf(), v.LoadAvg]);                                
                                return subData;
                            })
                        });
                    });

                    
                    poltChart(_dta);
                },
                poltChart = function (data) {
                    var sales_charts = $('#sales-charts').css({ 'width': '100%', 'height': '270px' });
                    $.plot("#sales-charts", data, {
                        shadowSize: 0,
                        series: {
                            lines: { show: true },
                            points: { show: true },
                            label: { show: true }
                        },
                        //xaxis: { tickLength: 0 },
                        //yaxis: {
                        //    ticks: 10,
                        //    min: 0,
                        //    max: 1000,
                        //    tickDecimals: 100
                        //},
                        xaxes: [{ mode: "time" }],
                        yaxes: [{ min: 0, max: 1000 }],
                        grid: {
                            backgroundColor: { colors: ["#fff", "#fff"] },
                            borderWidth: 1,
                            borderColor: '#d9d9d9',

                            clickable: true,
                            hoverable: true
                        },
                        selection: {
                            mode: "x"
                        }
                    });

                    chartEvents();
                },
                chartEvents = function () {
                    // hover on the graph
                    var $tooltip = $("<div class='tooltip top in hide'><div class='tooltip-inner'></div></div>").appendTo('body'),
                        previousPoint = null;
                    $('#sales-charts').on('plothover', function (event, pos, item) {
                        if (item) {
                            var x = item.datapoint[0].toFixed(2),
                                y = item.datapoint[1].toFixed(2);

                            if (previousPoint != item.seriesIndex) {
                                previousPoint = item.seriesIndex;
                                var tip = item.series.label + " of " + x + " = " + y;
                                $tooltip.show().children(0).text(tip);
                            }
                            $tooltip.css({ top: pos.pageY + 10, left: pos.pageX + 10 });
                        } else {
                            $tooltip.hide();
                            previousPoint = null;
                        }
                    });//end tooltip                        
                    // click event on the chart
                    $('#sales-charts').bind("plotclick", function (event, pos, item) {
                        console.log(event, pos, item);
                        if (item) {
                            alert(" - click point " + item.dataIndex + " in " + item.series.label);
                            //plot.highlight(item.series, item.datapoint);
                        }
                    }); // end click

                    $('#sales-charts').bind("plotselected", function (event, ranges) {
                        $.each(plot.getXAxes(), function (_, axis) {
                            var opts = axis.options;
                            opts.min = ranges.xaxis.from;
                            opts.max = ranges.xaxis.to;
                        });

                        plot.setupGrid();
                        plot.draw();
                        plot.clearSelection();
                    });


                    //Android's default browser somehow is confused when tapping on label which will lead to dragging the task
                    //so disable dragging when clicking on label
                    var agent = navigator.userAgent.toLowerCase();
                    if ("ontouchstart" in document && /applewebkit/.test(agent) && /android/.test(agent))
                        $('#tasks').on('touchstart', function (e) {
                            var li = $(e.target).closest('#tasks li');
                            if (li.length == 0) return;
                            var label = li.find('label.inline').get(0);
                            if (label == e.target || $.contains(label, e.target)) e.stopImmediatePropagation();
                        });
                };


            // get data
            var dto = { 'actionName': 'HomeShipperExpStatistics', 'names': [], 'values': [] };
            dataService.callAjax('Post', JSON.stringify(dto), sUrl + 'GetDataList', bindChartData, commonManger.errorException);

        };


    return {
        Init: init
    };

}();


dashboardManager.Init();